import 'package:makemyevent/core/app_export.dart';

class ApiClient extends GetConnect {}
