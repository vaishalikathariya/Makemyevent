final Map<String, String> enUs = {
  'msg_network_err': 'Network Error',
  'msg_something_went_wrong': 'Something Went Wrong!',
  "msg_check_your_app_s":
      "Check your app's UI from the below demo screens of your app.",
  "lbl_fashion_event": "Fashion Event",
  "lbl_clubs": "Clubs",
  "lbl_description": "Description:",
  "lbl_home_page": "Home Page",
  "lbl_tech_events": "TeCH EVENTS",
  "lbl_register": "Register",
  "lbl_app_navigation": "App Navigation",
  "msg_fashion_event_one": "Fashion Event One",
  "lbl_fashion_events": "Fashion Events"
};
