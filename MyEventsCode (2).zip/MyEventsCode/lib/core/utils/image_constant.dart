class ImageConstant {
  static String imgImage8 = 'assets/images/img_image8.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgImage6 = 'assets/images/img_image6.png';

  static String imgImage2 = 'assets/images/img_image2.png';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgImage5 = 'assets/images/img_image5.png';

  static String imgImage10 = 'assets/images/img_image10.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgImage11 = 'assets/images/img_image11.png';

  static String imgImage7 = 'assets/images/img_image7.png';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgImage1 = 'assets/images/img_image1.png';

  static String imgImage3 = 'assets/images/img_image3.png';

  static String imgImage4 = 'assets/images/img_image4.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
