class FashionEventModel {}
