class FashionEventOneModel {}
