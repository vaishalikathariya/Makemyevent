// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
//
// class UserImage extends StatefulWidget {
//
//   final Function(String imageURL) onFileChanged;
//   UserImage({
//     required this.onFileChanged,
// });
//
//   @override
//   _UserImageState createState() => _UserImageState();
// }
//
// class _UserImageState extends State<UserImage> {
//
//   final ImagePicker _picker = ImagePicker();
//   String? imageURL;
//   @override
//   Widget build(BuildContext context){}
// }